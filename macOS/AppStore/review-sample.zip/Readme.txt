VibeZip review sample

These demonstration files contain no personal data.
Extract this ZIP to obtain local files for archive creation.
Open Samples/Nested.zip to try preview, or open it inside this ZIP to try nested browsing.
No password is required.
